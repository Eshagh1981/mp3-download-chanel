package com.example.channeldl

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shared = intent?.getStringExtra(Intent.EXTRA_TEXT) ?: ""
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme { Surface(Modifier.fillMaxSize()) { Screen(shared) } }
            }
        }
    }
}

@Composable
fun Screen(initial: String) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var link by remember { mutableStateOf(initial) }
    var result by remember { mutableStateOf<ScanResult?>(null) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var folder by remember { mutableStateOf(prefs.getString("folder", null)?.let(Uri::parse)) }
    var filter by remember { mutableStateOf("صوتی") }
    val selected = remember { mutableStateListOf<String>() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            prefs.edit().putString("folder", uri.toString()).apply()
            folder = uri
        }
    }

    val visible = result?.items?.filter { filter == "همه" || it.type == filter } ?: emptyList()

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(link, { link = it }, Modifier.fillMaxWidth(),
            label = { Text("لینک کانال (روبیکا، واتساپ، تلگرام یا هر لینک)") }, singleLine = true)
        Button({
            scope.launch {
                busy = true; status = "در حال بررسی…"; result = null; selected.clear()
                try {
                    val r = withContext(Dispatchers.IO) { scan(link) }
                    result = r
                    filter = if (r.items.any { it.type == "صوتی" }) "صوتی" else "همه"
                    selected.addAll(r.items.filter { it.type == "صوتی" }.map { it.url })
                    status = r.note ?: "${r.items.size} فایل پیدا شد"
                } catch (e: Exception) { status = "خطا: ${e.message}" }
                busy = false
            }
        }, enabled = !busy && link.isNotBlank()) { Text("بررسی لینک") }

        result?.let { r ->
            Text("پیام‌رسان: ${r.platform}  |  کانال: ${r.title}", style = MaterialTheme.typography.titleSmall)
            val counts = r.items.groupingBy { it.type }.eachCount()
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(filter == "همه", { filter = "همه" }, { Text("همه (${r.items.size})") })
                counts.forEach { (t, n) -> FilterChip(filter == t, { filter = t }, { Text("$t ($n)") }) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton({ selected.addAll(visible.map { it.url }.filter { it !in selected }) }) { Text("انتخاب همه") }
                TextButton({ selected.removeAll(visible.map { it.url }.toSet()) }) { Text("لغو انتخاب") }
            }
        }

        LazyColumn(Modifier.weight(1f)) {
            items(visible, key = { it.url }) { f ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(f.url in selected, { c -> if (c) selected.add(f.url) else selected.remove(f.url) })
                    Column { Text(f.name, maxLines = 1); Text(f.type, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }

        Text(status, style = MaterialTheme.typography.bodySmall)
        OutlinedButton({ picker.launch(null) }, Modifier.fillMaxWidth()) {
            Text(if (folder == null) "انتخاب پوشهٔ ذخیره" else "پوشه: ${Uri.decode(folder.toString()).substringAfterLast(':')}")
        }
        Button({
            val dir = DocumentFile.fromTreeUri(ctx, folder!!)!!
            val todo = result!!.items.filter { it.url in selected }
            scope.launch {
                busy = true
                var ok = 0
                todo.forEachIndexed { i, f ->
                    status = "دانلود ${i + 1}/${todo.size}: ${f.name}"
                    runCatching { withContext(Dispatchers.IO) { download(ctx, dir, f) } }.onSuccess { ok++ }
                }
                status = "تمام شد: $ok از ${todo.size} فایل ذخیره شد"
                busy = false
            }
        }, Modifier.fillMaxWidth(), enabled = !busy && folder != null && selected.isNotEmpty()) {
            Text("دانلود ${selected.size} فایل انتخاب‌شده")
        }
    }
}

fun download(ctx: Context, dir: DocumentFile, f: Item) {
    var name = f.name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
    if (dir.findFile(name) != null) name = "${System.currentTimeMillis()}_$name"
    val mime = when (f.type) { "صوتی" -> "audio/*"; "ویدیو" -> "video/*"; "تصویر" -> "image/*"; else -> "application/octet-stream" }
    val out = dir.createFile(mime, name) ?: error("ساخت فایل ممکن نشد")
    URL(f.url).openStream().use { i -> ctx.contentResolver.openOutputStream(out.uri)!!.use { o -> i.copyTo(o) } }
}

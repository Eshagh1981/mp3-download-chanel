package com.example.channeldl

import android.text.Html
import java.net.HttpURLConnection
import java.net.URL

data class Item(val url: String, val name: String, val type: String)
data class ScanResult(val platform: String, val title: String, val items: List<Item>, val note: String?)

private val EXT = mapOf(
    "صوتی" to listOf("mp3", "m4a", "ogg", "oga", "opus", "wav", "aac", "flac"),
    "ویدیو" to listOf("mp4", "mkv", "webm"),
    "تصویر" to listOf("jpg", "jpeg", "png", "gif", "webp"),
    "سند/آرشیو" to listOf("pdf", "zip", "rar", "apk")
)
private val FILE_RE = Regex(
    "(?:href|src)=[\"']([^\"']+?\\.(?:" + EXT.values.flatten().joinToString("|") + ")(?:\\?[^\"']*)?)[\"']",
    RegexOption.IGNORE_CASE
)

fun typeOf(name: String): String {
    val e = name.substringAfterLast('.', "").lowercase()
    return EXT.entries.firstOrNull { e in it.value }?.key ?: "سایر"
}

fun fetch(url: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile")
    c.connectTimeout = 15000; c.readTimeout = 20000
    return c.inputStream.bufferedReader().use { it.readText() }
}

private fun meta(html: String, prop: String): String? =
    Regex("<meta[^>]+property=[\"']$prop[\"'][^>]+content=[\"']([^\"']*)[\"']", RegexOption.IGNORE_CASE)
        .find(html)?.groupValues?.get(1)?.let { Html.fromHtml(it, Html.FROM_HTML_MODE_LEGACY).toString() }

private fun extract(html: String, base: String): List<Item> =
    FILE_RE.findAll(html).mapNotNull {
        runCatching {
            val abs = URL(URL(base), it.groupValues[1].replace("&amp;", "&")).toString()
            val name = abs.substringBefore('?').substringAfterLast('/')
            Item(abs, name, typeOf(name))
        }.getOrNull()
    }.toList()

fun scan(input: String): ScanResult {
    val link = input.trim().let { if (it.startsWith("http")) it else "https://$it" }
    val host = URL(link).host.lowercase()
    val platform = when {
        "t.me" in host || "telegram" in host -> "تلگرام"
        "whatsapp" in host -> "واتساپ"
        "rubika" in host -> "روبیکا"
        else -> "وب"
    }
    // لینک مستقیم فایل
    if (typeOf(link.substringBefore('?')) != "سایر") {
        val n = link.substringBefore('?').substringAfterLast('/')
        return ScanResult(platform, host, listOf(Item(link, n, typeOf(n))), null)
    }
    var page = link
    var title = ""
    val items = LinkedHashMap<String, Item>()
    if (platform == "تلگرام") {
        val seg = URL(link).path.trim('/').split('/').filter { it.isNotEmpty() }
        val name = if (seg.firstOrNull() == "s") seg.getOrNull(1) else seg.firstOrNull()
        if (name != null) page = "https://t.me/s/$name"
        var lastMin = Long.MAX_VALUE
        repeat(8) {
            val html = fetch(page)
            if (title.isEmpty()) title = meta(html, "og:title") ?: name ?: ""
            extract(html, page).forEach { items.putIfAbsent(it.url, it) }
            val min = Regex("data-post=\"[^\"]+/(\\d+)\"").findAll(html).map { it.groupValues[1].toLong() }.minOrNull()
            if (min == null || min >= lastMin || min <= 1) return@repeat
            lastMin = min
            page = "https://t.me/s/$name?before=$min"
        }
    } else {
        val html = fetch(page)
        title = meta(html, "og:title") ?: Regex("<title>(.*?)</title>", RegexOption.IGNORE_CASE).find(html)?.groupValues?.get(1) ?: host
        extract(html, page).forEach { items.putIfAbsent(it.url, it) }
    }
    val note = if (items.isEmpty()) when (platform) {
        "واتساپ", "روبیکا" -> "این پیام‌رسان محتوای کانال را در صفحهٔ عمومی وب قرار نمی‌دهد؛ فقط نام کانال تشخیص داده شد. برای دانلود، لینک مستقیم فایل را بدهید."
        else -> "فایلی در این صفحه پیدا نشد."
    } else null
    return ScanResult(platform, title.ifBlank { host }, items.values.toList(), note)
}
